from pymongo import MongoClient


class AnimalShelter(object):
    """
    CRUD operations for the animals collection in MongoDB.
    Represents the Model component in the MVC architecture.
    """

    def __init__(self, username, password):
        """
        Initialize the MongoDB connection using provided credentials.

        :param username: MongoDB username
        :param password: MongoDB password
        """
        HOST = 'localhost'
        PORT = 27017
        DB = 'aac'
        COL = 'animals'

        try:
            self.client = MongoClient(
                f'mongodb://{username}:{password}@{HOST}:{PORT}/?authSource=admin'
            )
            self.database = self.client[DB]
            self.collection = self.database[COL]
        except Exception as e:
            print("Connection failed:", e)

    def create(self, data):
        """
        Insert a document into the animals collection.

        :param data: Dictionary containing animal data
        :return: True if successful, False otherwise
        """
        try:
            if data is not None:
                self.collection.insert_one(data)
                return True
            raise Exception("Nothing to save, data parameter is empty")
        except Exception as e:
            print("Create failed:", e)
            return False

    def read(self, query):
        """
        Query documents from the animals collection.

        :param query: Dictionary used to search for matching documents
        :return: List of matching documents, or an empty list on failure
        """
        try:
            cursor = self.collection.find(query)
            results = list(cursor)

            if len(results) == 0:
                print("No matching records found.")

            return results
        except Exception as e:
            print("Read failed:", e)
            return []

    def update(self, query, new_values, multiple=False):
        """
        Update document(s) in the animals collection.

        :param query: Dictionary with search criteria
        :param new_values: Dictionary of fields to update
        :param multiple: Boolean indicating whether to update many documents
        :return: Number of documents modified
        """
        try:
            if query is not None and new_values is not None:
                update_operation = {"$set": new_values}

                if multiple:
                    result = self.collection.update_many(query, update_operation)
                else:
                    result = self.collection.update_one(query, update_operation)

                return result.modified_count

            raise Exception("Missing query or update data")
        except Exception as e:
            print("Update failed:", e)
            return 0

    def delete(self, query, multiple=False):
        """
        Delete document(s) from the animals collection.

        :param query: Dictionary with search criteria
        :param multiple: Boolean indicating whether to delete many documents
        :return: Number of documents deleted
        """
        try:
            if query is not None:
                if multiple:
                    result = self.collection.delete_many(query)
                else:
                    result = self.collection.delete_one(query)

                return result.deleted_count

            raise Exception("Query is empty")
        except Exception as e:
            print("Delete failed:", e)
            return 0